// Импорт нужных библиотек
import org.jsfml.graphics.*;
import org.ns.matrixengine.*;
import org.ns.matrixengine.Object;

import java.io.IOException;
import java.nio.file.Paths;

public class Menu extends Scene {
    Texture texture;
    Object object;

    public Menu(RenderWindow window) throws IOException {

        // Эта функция необходима для корректной работы сцены

        super(window);
        SceneRenderer.scenes.add(this);
        Start();
    }

    @Override
    public void Start() throws IOException {

        // ФУНКЦИЯ Start()
        // весь код в ней выполнится при создании сцены

        texture = new Texture(); // создание текстуры
        texture.loadFromFile(Paths.get("src/main/java/4let.png"));

        object = new Object(this, texture); // Создание объекта

        object.setScale(0.3f, 0.3f);
        object.setOpacity(50);

        setBackground(new Color(105,  60, 100)); // Установка цвета фона
        setActive(true); // Установка параметра отрисовка сцены (активности)
    }
    @Override
    public void Update() {

        // Эта функция выполняется каждый кадр
        object.setPosition(
                Input.getMousePosition().x,
                Input.getMousePosition().y
        );
        object.render(this); // отрисовка объекта

    }
}
