import org.jsfml.graphics.*;
import org.jsfml.window.VideoMode;
import org.jsfml.window.event.*;
import org.ns.matrixengine.SceneRenderer;

import java.io.IOException;

public class Main {

    static Menu menu;

    public static void main(String[] args) throws IOException {
        RenderWindow win = new RenderWindow(
            new VideoMode(500, 400), "Hello"
        );

        menu = new Menu(win);
        

        while (win.isOpen()) {
            Iterable<Event> events = win.pollEvents();
            for (Event event : events) {
                if (event.type == Event.Type.CLOSED) {
                    win.close();
                }
            }

            SceneRenderer.render(win);

        }
    }
}