package org.ns.matrixengine;

import org.jsfml.graphics.RenderWindow;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SceneRenderer {
    public static List<Scene> scenes = new ArrayList<>();
    public static RenderWindow win;

    public static void render(RenderWindow window) throws IOException {
        win = window;


        for (Scene scene : scenes) {
            if (scene.isActive) {
                window.clear(scene.background);
                scene.Update();
                window.display();
            }
        }
    }
}