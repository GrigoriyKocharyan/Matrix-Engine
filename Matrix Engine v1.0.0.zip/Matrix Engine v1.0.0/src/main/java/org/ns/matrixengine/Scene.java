package org.ns.matrixengine;

import org.jsfml.graphics.*;

import java.io.IOException;
import java.util.*;

public abstract class Scene {
    public RenderWindow window = new RenderWindow();
    public List<Object> objects = null;
    public Color background = new Color(0, 0, 0);
    public boolean isActive = false;

    public Scene(RenderWindow window) throws IOException {
        this.window = window;
        SceneRenderer.scenes.add(this);
        Start();
    }

    public void setActive(boolean value) {
        isActive = value;
    }

    public void Start() throws IOException {

    }

    public void setBackground(Color color) {
        background = color;
    }

    public void Update() throws IOException {

    }

}
