package org.ns.matrixengine;

import org.jsfml.graphics.*;
import org.jsfml.system.Vector2f;

public class Object {
    Texture texture = new Texture();
    float x, y;
    float scaleX, scaleY;
    float width, height;
    Color color = new Color(255, 255, 255, 255);
    int rotation;
    Sprite sprite;

    public Object(Scene scene, Texture texture) {
        x = 100;
        y = 100;
        this.texture = texture;
        sprite = new Sprite();
        sprite.setTexture(texture);
        sprite.setPosition(x, y);

    }
 public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
        sprite.setPosition(x, y);
    }

    public void render(Scene scene) {
        scene.window.draw(sprite);
    }

    public void setOpacity(int value) {
        sprite.setColor(new Color(
                color.r,
                color.g,
                color.b,
                value
        ));
    }

    public void setRotation(int value) {
        rotation = value;
        sprite.setRotation(rotation);
    }

    public Vector2f getSize() {
        return new Vector2f(
            texture.getSize().x * sprite.getScale().x,
            texture.getSize().y * sprite.getScale().y
        );
    }

    public void setScale(float width, float height) {
        this.scaleX = width;
        this.scaleY = height;
        sprite.setScale(scaleX, scaleY);
    }

    public void setTexture(Texture texture) {
        this.texture = texture;
        sprite.setTexture(texture);
    }

}
