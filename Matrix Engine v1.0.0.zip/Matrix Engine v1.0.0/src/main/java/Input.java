import org.jsfml.system.Vector2i;
import org.jsfml.window.Mouse;
import org.ns.matrixengine.SceneRenderer;

public class Input {

    public static Vector2i getMousePosition() {
        if (SceneRenderer.win != null) {
            return new Vector2i(
                    Mouse.getPosition(SceneRenderer.win).x,
                    Mouse.getPosition(SceneRenderer.win).y
            );
        }
        return new Vector2i(0, 0);
    }

}
